package com.heypixel.heypixel.VcX6svVqmeT8.events.impl;

import com.heypixel.heypixel.VcX6svVqmeT8.events.api.events.Event;
import net.minecraft.network.chat.Component;

public class EventRenderScoreboard implements Event {
   private Component component;

   public EventRenderScoreboard(Component component) {
      this.component = component;
   }

   public Component getComponent() {
      return this.component;
   }

   public void setComponent(Component component) {
      this.component = component;
   }
}
