package com.heypixel.heypixel.VcX6svVqmeT8.utils;

public class FontIcons {
   public static String RESIZE = "\ue904";
   public static String SWORD = "\ue903";
   public static String RUNNING = "\ue902";
   public static String EYE = "\ue901";
   public static String OTHER = "\ue900";
}
